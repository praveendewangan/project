<?php

if(isset($_GET['name']))
{
	echo "GET: You name is ".$_GET['name'];
}
if(isset($_POST['name']))
{
//	echo "POST: You name is ".$_POST['name'];
	echo ($_POST['name']);
}
echo ($_POST['name']);	
?>