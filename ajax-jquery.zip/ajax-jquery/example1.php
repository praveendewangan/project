<html>
<head>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
    <input type="text" id="name">
    <button id="button" class="btn btn-info">Call Ajax</button>
    <div class="msg"></div>
<script type="text/javascript" src="bootstrap/js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="ajax1.js"></script>
</body>
</html>