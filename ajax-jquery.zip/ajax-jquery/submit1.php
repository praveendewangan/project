<?php

if(isset($_POST['val']))
{
    echo "<button class='btn btn-primary'>".$_POST['val']."</button>";
}
?>