
// $(document).ready(function()
// {
//     $('#button').click(function()
//     {
//         var store = $("#name").val();
//         $.get(
//             'submit1.php',
//             {val:store},
//             function(feedback)
//             {
//                 $(".msg").html(feedback);
//             });
//     });
// });


$(document).ready(function()
{
    $('#button').click(function()
    {
        var store = $("#name").val();
        $.ajax(
            {
                type: 'POST',
                url: 'submit1.php',
                data: {val:store},
                success: function(feedback)
                {
                    $('.msg').html(feedback);
                }
            }
        );
    });
});