<?php


// $con = new PDO('mysql:host=localhost;dbname=ajax','root','');
// print_r($con);exit;
// if(isset($_GET['store']))
// {
//     $store = $_GET['store'];
//     $query = $con->prepare("Select `name from `players` where `name` LIKE ?");
//     // $query->;
//     $query->execute(array("$store%"));
//     while($r = $q->fetch(PDO::FETCH_OBJ))
//     {
//         echo $r->name,"<br>";
//     }
// }


$con = mysqli_connect('localhost','root','');
if(!mysqli_select_db($con,'ajax'))
{
    echo "error";
    exit;
}
if(isset($_GET['store']))
{
    if(!empty($_GET['store']))
    {
        $store = $_GET['store'];
        $query = "Select `name` from `players` where `name` LIKE '$store%'";
        $query_run = mysqli_query($con,$query);
        while($query_row = mysqli_fetch_assoc($query_run))
        {
            echo $query_row['name'],"<br>";
        }
        
    }

}

?>