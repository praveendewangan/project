function ajax()
{
    if(window.XMLHttpRequest)
    {
       xml = new XMLHttpRequest();
    }
    else
    {
       xml = new ActiveXObject('Microsoft.XMLHTTP');
    }

    xml.onreadystatechange = function()
    {
        if(xml.readyState == 4 && xml.status == 200)
        {
            document.getElementById('display').innerHTML = xml.responseText;
        }
        else
        {
            document.getElementById('display').innerHTML = xml.responseError;
        }
    }
    xml.open('GET','submit1.php',true);
    xml.send();
}


// example2
function ajax2(recieve)
{
    if(window.XMLHttpRequest)
    {
       xml = new XMLHttpRequest();
    }
    else
    {
       xml = new ActiveXObject('Microsoft.XMLHTTP');
    }

    xml.onreadystatechange = function()
    {
        if(xml.readyState == 4 && xml.status == 200)
        {
            document.getElementById('display2').innerHTML = xml.responseText;
        }
        else
        {
            document.getElementById('display2').innerHTML = xml.responseError;
        }
    }
    xml.open('GET','submit2.php?store='+recieve,true);
    xml.send();
}