<html>
    <head>
        <script type="text/javascript" src="ajax1.js"></script>
    </head>
    <body>
    <input type="submit" value="ajax button" onclick="ajax();">
    <div id="display"></div>
    </body>
</html>