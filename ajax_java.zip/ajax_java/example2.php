<html>
    <head>
        <script type="text/javascript" src="ajax1.js"></script>
    </head>
    <body>
    <input type="text" onkeyup="ajax2(this.value);">
    <div id="display2"></div>
    </body>
</html>