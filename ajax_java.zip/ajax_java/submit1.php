<?php

echo "ajax example 1.";
?>